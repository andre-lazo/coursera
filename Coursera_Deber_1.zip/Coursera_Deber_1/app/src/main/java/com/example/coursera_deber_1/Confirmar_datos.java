package com.example.coursera_deber_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

public class Confirmar_datos extends AppCompatActivity {
    TextView txt_nombre,txt_telefono,txt_email,txt_descripcion,txt_fecha;

    Button btn_editar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar_datos);
        Bundle datos= getIntent().getExtras();
        String nombre=datos.getString("nombre");
        String fecha=datos.getString("fecha");
        String telefono=datos.getString("telefono");
        String email=datos.getString("email");
        String descripcion=datos.getString("descripcion");
        txt_nombre=findViewById(R.id.txt_nombre2);
        txt_telefono=findViewById(R.id.txt_telefono2);
        txt_email=findViewById(R.id.txt_email2);
        txt_descripcion=findViewById(R.id.txt_descripcion2);
        txt_fecha=findViewById(R.id.txt_fecha2);
        txt_nombre.setText(nombre);
        txt_telefono.setText(telefono);
        txt_email.setText(email);
        txt_descripcion.setText(descripcion);
        txt_fecha.setText(fecha);
        btn_editar=findViewById(R.id.btn_editar);
        btn_editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(Confirmar_datos.this,MainActivity.class);
                i.putExtra("nombre",txt_nombre.getText().toString());
                i.putExtra("fecha" ,txt_fecha.getText().toString());
                i.putExtra("telefono",txt_telefono.getText().toString());
                i.putExtra("email",txt_email.getText().toString());
                i.putExtra("descripcion",txt_descripcion.getText().toString());
                startActivity(i);
                finish();
            }
        });


    }
}