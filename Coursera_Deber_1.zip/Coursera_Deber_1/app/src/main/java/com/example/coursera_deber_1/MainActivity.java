package com.example.coursera_deber_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
EditText txt_nombre,txt_telefono,txt_email,txt_descripcion;
DatePicker txt_dtfecha;
Button btn_siguiente;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt_nombre=findViewById(R.id.txt_nombre);
        txt_telefono=findViewById(R.id.txt_telefono);
        txt_email=findViewById(R.id.txt_email);
        txt_descripcion=findViewById(R.id.txt_descripcion);
        txt_dtfecha=findViewById(R.id.date_fecha);
        Bundle datos= getIntent().getExtras();
        if(datos!=null){
            txt_nombre.setText(datos.getString("nombre"));
            String fecha=datos.getString("fecha");
            String[]f=fecha.split("/");
            txt_dtfecha.updateDate(Integer.parseInt(f[0]),Integer.parseInt(f[1]),Integer.parseInt(f[2]));
            txt_telefono.setText(datos.getString("telefono"));
            txt_email.setText(datos.getString("email"));
            txt_descripcion.setText(datos.getString("descripcion"));
        }

        btn_siguiente=findViewById(R.id.btn_siguiente);
        btn_siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i= new Intent(MainActivity.this,Confirmar_datos.class);
                i.putExtra("nombre",txt_nombre.getText().toString());
                i.putExtra("fecha",txt_dtfecha.getYear()+"/"+txt_dtfecha.getMonth()+"/"+txt_dtfecha.getDayOfMonth());
                i.putExtra("telefono",txt_telefono.getText().toString());
                i.putExtra("email",txt_email.getText().toString());
                i.putExtra("descripcion",txt_descripcion.getText().toString());
                startActivity(i);
                finish();
            }
        });
    }
}